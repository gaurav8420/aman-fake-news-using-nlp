from django.apps import AppConfig


class FakenewsdetectorConfig(AppConfig):
    name = 'FakeNewsDetector'
